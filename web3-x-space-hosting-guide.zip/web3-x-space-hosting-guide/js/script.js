/*
  The Ultimate Guide to Web3 X Space Hosting — site script
  Kept deliberately small. The page works without JavaScript;
  this file only adds: the mobile menu, an automatic GitHub
  repository link, and sharing. No tracking, no third parties.
*/
(function () {
  "use strict";

  document.documentElement.classList.remove("no-js");

  /* ---------- Mobile navigation ---------- */
  var toggle = document.querySelector(".nav-toggle");
  var nav = document.getElementById("site-nav");

  function setMenu(open) {
    if (!toggle || !nav) return;
    toggle.setAttribute("aria-expanded", String(open));
    nav.classList.toggle("is-open", open);
  }

  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      setMenu(toggle.getAttribute("aria-expanded") !== "true");
    });
    // Close after choosing a section, so the content is visible
    nav.addEventListener("click", function (e) {
      if (e.target.closest("a")) setMenu(false);
    });
    // Escape closes the menu and returns focus to the toggle
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && toggle.getAttribute("aria-expanded") === "true") {
        setMenu(false);
        toggle.focus();
      }
    });
    // Reset when resizing back to desktop
    window.matchMedia("(min-width: 961px)").addEventListener("change", function (mq) {
      if (mq.matches) setMenu(false);
    });
  }

  /* ---------- GitHub link ----------
     On GitHub Pages (https://USER.github.io/REPO/) the repository
     address can be worked out automatically, so the "View on GitHub"
     button points to the right place without manual editing.
     Elsewhere, the address written in index.html is used. */
  var host = window.location.hostname;
  if (/\.github\.io$/i.test(host)) {
    var user = host.split(".")[0];
    var firstPath = window.location.pathname.split("/").filter(Boolean)[0];
    var repo = firstPath && !/\.html?$/i.test(firstPath) ? firstPath : host; // user-site repos are named USER.github.io
    var repoUrl = "https://github.com/" + user + "/" + repo;
    document.querySelectorAll("[data-github-link]").forEach(function (a) { a.href = repoUrl; });
  }

  /* ---------- Sharing ---------- */
  var pageUrl = window.location.href.split("#")[0];
  var title = "The Ultimate Guide to Web3 X Space Hosting";
  var text = "A practical TrustChain Academy handbook on hosting, moderation and Web3 safety on X Spaces.";
  var status = document.querySelector(".share-status");

  var xLink = document.querySelector("[data-share-x]");
  if (xLink) {
    xLink.href = "https://x.com/intent/post?text=" + encodeURIComponent(title + ": " + text) + "&url=" + encodeURIComponent(pageUrl);
  }
  var liLink = document.querySelector("[data-share-linkedin]");
  if (liLink) {
    liLink.href = "https://www.linkedin.com/sharing/share-offsite/?url=" + encodeURIComponent(pageUrl);
  }

  function say(message) {
    if (status) status.textContent = message;
  }

  var shareBtn = document.querySelector("[data-share]");
  if (shareBtn) {
    shareBtn.addEventListener("click", function () {
      // Native share sheet where available (most phones)
      if (navigator.share) {
        navigator.share({ title: title, text: text, url: pageUrl }).catch(function () { /* user closed the sheet */ });
        return;
      }
      // Otherwise copy the link
      if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(pageUrl).then(
          function () { say("Link copied. Paste it wherever you’d like to share the guide."); },
          function () { say("Copy this link to share the guide: " + pageUrl); }
        );
      } else {
        say("Copy this link to share the guide: " + pageUrl);
      }
    });
  }
})();
